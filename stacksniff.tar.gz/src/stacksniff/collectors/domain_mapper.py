"""Map external and internal domain dependencies for a scan target.

Part 1 — External dependencies
    Parses HAR entries to find every cross-origin domain the page contacted.
    Groups requests by domain and reverse-looks up each domain against the
    loaded FingerprintStore to determine its technology category — no hardcoded
    category map, all labels come from the Wappalyzer-sourced tech.yaml.

Part 2 — Internal subdomains
    Queries crt.sh Certificate Transparency logs to discover every subdomain
    that has ever had a certificate issued for the target domain, then probes
    each one concurrently with httpx (30-connection semaphore, 5 s per probe)
    to record live status codes and response metadata.  Each responsive
    subdomain is also matched against the FingerprintStore using its response
    headers so we can report what tech stack it runs.

Returned ``data`` dict shape::

    {
        "external_dependencies": [<ExternalDep dict>, ...],
        "internal_subdomains": [<InternalSub dict>, ...],
    }

ExternalDep dict::

    {
        "domain":           str,
        "category":         str,   # from Wappalyzer fingerprint, or "Unclassified"
        "technology_name":  str | None,
        "resource_types":   list[str],
        "request_count":    int,
        "example_urls":     list[str],
    }

InternalSub dict::

    {
        "subdomain":          str,
        "full_url":           str,
        "status_code":        int,
        "content_type":       str | None,
        "redirect_location":  str | None,
        "response_time_ms":   float,
        "detected_tech":      str | None,
        "detected_category":  str | None,
    }
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import httpx

from stacksniff.collectors.base import CollectorResult
from stacksniff.utils import get_apex_domain

if TYPE_CHECKING:
    from stacksniff.fingerprints import Fingerprint, FingerprintStore

logger = logging.getLogger(__name__)





# Maximum concurrent subdomain probes (Pattern 9 from async playbook: Semaphore)
_PROBE_CONCURRENCY = 30
_PROBE_TIMEOUT = 5.0      # per-subdomain HEAD request timeout
_CRTSH_TIMEOUT = 10.0     # crt.sh JSON fetch timeout


# Shared/platform domains for which subdomain/suffix-based tech matching is disallowed
_SHARED_DOMAINS: frozenset[str] = frozenset({
    "google.com",
    "github.com",
    "github.io",
    "microsoft.com",
    "apple.com",
    "amazon.com",
    "oracle.com",
    "cloudflare.com",
    "wordpress.com",
    "wordpress.org",
    "adobe.com",
    "facebook.com",
    "twitter.com",
    "yahoo.com",
})

# Brand-matching stopwords — terms common in tech names but not domain identifiers.
_BRAND_STOPWORDS: frozenset[str] = frozenset({
    "api", "apis", "cdn", "sdk", "js", "static", "hosted", "libraries",
    "font", "fonts", "page", "pages", "web", "service", "services",
    "platform", "platforms", "cloud",
})

# Regex special characters used in _is_safe_literal_pattern.
_REGEX_SPECIALS: frozenset[str] = frozenset(r"^$[]{}()|*+?\\")


class DomainMapper:
    """Collector that maps external and internal domain dependencies.

    Parameters
    ----------
    base_url:
        The scan target URL (e.g. ``https://aiori.in``).
    har_entries:
        Raw HAR entry dicts produced by
        :class:`~stacksniff.collectors.network_collector.NetworkCollector`.
        Each entry must have at least a ``url`` key.
    fingerprint_store:
        Loaded :class:`~stacksniff.fingerprints.FingerprintStore` used for
        reverse-lookup to classify external domains and subdomain stacks.
    timeout:
        Overall timeout budget (seconds).  crt.sh query uses its own
        ``_CRTSH_TIMEOUT`` cap; subdomain probes use ``_PROBE_TIMEOUT``.
    """

    def __init__(
        self,
        base_url: str,
        har_entries: list[dict[str, Any]],
        fingerprint_store: FingerprintStore,
        *,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url
        self._har_entries = har_entries
        self._store = fingerprint_store
        self._timeout = timeout
        self.errors: list[str] = []

        parsed = urlparse(base_url)
        self._target_netloc: str = parsed.netloc.lower()
        # Bare domain without www prefix / port for crt.sh query
        host = self._target_netloc.split(":")[0]
        self._target_domain: str = host.removeprefix("www.")
        # Apex domain used for same-origin subdomain check (Fix 1)
        self._target_apex: str = get_apex_domain(self._target_domain)

    # ------------------------------------------------------------------
    # Public collector interface
    # ------------------------------------------------------------------

    async def collect(self) -> CollectorResult:
        """Run both mapping phases and return combined CollectorResult."""
        result = CollectorResult()
        self.errors = []

        # Phase 1: external dependencies — pure in-memory, no I/O
        try:
            external_deps = self._build_external_dependencies()
        except Exception as exc:  # noqa: BLE001
            logger.exception("DomainMapper external dependency phase error")
            result.add_error(f"External dependency mapping error: {exc}")
            external_deps = []

        # Phase 2: internal subdomains — async I/O
        try:
            internal_subs = await self._discover_internal_subdomains()
        except Exception as exc:  # noqa: BLE001
            logger.exception("DomainMapper internal subdomain phase error")
            result.add_error(f"Internal subdomain discovery error: {exc}")
            internal_subs = []

        for err in self.errors:
            result.add_error(err)

        result.data = {
            "external_dependencies": external_deps,
            "internal_subdomains": internal_subs,
        }
        return result

    # ------------------------------------------------------------------
    # Part 1 — External dependencies
    # ------------------------------------------------------------------

    def _build_external_dependencies(self) -> list[dict[str, object]]:
        """Group HAR entries by cross-origin domain and classify via fingerprints."""
        # Group: domain -> accumulated info
        groups: dict[str, dict[str, Any]] = {}

        for entry in self._har_entries:
            url_str = entry.get("url", "")
            if not url_str:
                continue
            try:
                parsed = urlparse(url_str)
                netloc = parsed.netloc.lower()
            except Exception:
                continue

            # Skip same-origin (including subdomains) and entries with no netloc
            # Fix 1: compare apex domains so v2.aiori.in is treated as internal
            if not netloc:
                continue
            host_only = netloc.split(":")[0].removeprefix("www.")
            if get_apex_domain(host_only) == self._target_apex:
                continue

            rtype = entry.get("resource_type", "") or ""

            if netloc not in groups:
                groups[netloc] = {
                    "domain": netloc,
                    "resource_types": set(),
                    "request_count": 0,
                    "example_urls": [],
                }

            g = groups[netloc]
            req_count = g.get("request_count", 0)
            g["request_count"] = (req_count if isinstance(req_count, int) else 0) + 1
            if rtype:
                res_types = g.get("resource_types")
                if isinstance(res_types, set):
                    res_types.add(rtype)
            ex_urls = g.get("example_urls")
            if isinstance(ex_urls, list) and len(ex_urls) < 3:
                ex_urls.append(url_str)

        # Fingerprint reverse-lookup for every external domain
        all_fingerprints = self._store.get_all()
        result: list[dict[str, object]] = []

        def _get_sort_key(item: tuple[str, dict[str, Any]]) -> int:
            count = item[1].get("request_count", 0)
            return -int(count) if isinstance(count, (int, float)) else 0

        for domain, info in sorted(groups.items(), key=_get_sort_key):
            tech_name, tech_category = self._classify_domain(domain, all_fingerprints)
            res_types_val = info.get("resource_types")
            res_types_list = sorted(list(res_types_val)) if isinstance(res_types_val, set) else []
            result.append(
                {
                    "domain": domain,
                    "category": tech_category or "Unclassified",
                    "technology_name": tech_name,
                    "resource_types": res_types_list,
                    "request_count": info.get("request_count", 0),
                    "example_urls": info.get("example_urls", []),
                }
            )

        return result

    def _is_specific_match(self, pattern_str: str, target_string: str) -> bool:
        """Check if pattern_str matches target_string, but does NOT match a dummy random string."""
        try:
            if re.search(pattern_str, target_string, re.IGNORECASE):
                # Verify it doesn't match a generic dummy string
                dummy = "dummy-random-string-that-should-never-match-1234567890.com"
                if not re.search(pattern_str, dummy, re.IGNORECASE):
                    return True
        except re.error:
            # Fallback for plain string
            if pattern_str.lower() in target_string.lower():
                dummy = "dummy-random-string-that-should-never-match-1234567890.com"
                if pattern_str.lower() not in dummy:
                    return True
        return False

    def _extract_domain_from_pattern(self, pattern: str) -> str | None:
        """Scan a regex script pattern character-by-character to extract the longest
        leading static domain prefix, unescaping dots/hyphens/slashes/colons and stopping
        at regex control characters.
        """
        # Clean leading ^ and protocols
        pat = pattern
        if pat.startswith("^"):
            pat = pat[1:]

        pat = re.sub(r'^(?:https?\??(?::|\\:)?(?:[\\/]+)|[\\/]{2,})', '', pat, flags=re.IGNORECASE)

        prefix = ""
        i = 0
        n = len(pat)
        while i < n:
            char = pat[i]
            if char == "\\":
                if i + 1 < n:
                    next_char = pat[i + 1]
                    if next_char in {".", "-", ":"}:
                        prefix += next_char
                        i += 2
                        continue
                    elif next_char == "/":
                        break
                    else:
                        break
                else:
                    break
            elif char in "/([*+?{|$^":
                break
            else:
                prefix += char
                i += 1

        # Remove port if present
        prefix = prefix.split(":")[0]

        if not prefix:
            return None
        if "." not in prefix:
            return None

        # Validate domain labels
        labels = prefix.split(".")
        for label in labels:
            if not label:
                return None
            if not re.match(r"^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]$", label) and not (
                len(label) == 1 and label.isalnum()
            ):
                return None

        return prefix.lower()

    def _brand_matches(self, tech_name: str, domain: str) -> bool:
        """Check if the technology name brand matches the target domain.
        Normalises the technology name into brand words (ignoring stopwords) and matches
        if any brand word exactly equals a domain label (excluding TLD) or starts with it
        (for brand words of length >= 5).
        """
        domain_labels = domain.lower().split(".")
        if len(domain_labels) > 1:
            domain_labels = domain_labels[:-1]

        brand_words = []
        for word in re.split(r"[^a-zA-Z0-9]+", tech_name):
            w = word.lower()
            if w and w not in _BRAND_STOPWORDS:
                brand_words.append(w)

        if not brand_words:
            return False

        for bw in brand_words:
            for label in domain_labels:
                if bw == label:
                    return True
                if len(bw) >= 5 and label.startswith(bw):
                    return True

        return False

    @staticmethod
    def _is_safe_literal_pattern(pattern: str) -> bool:
        """Return True if *pattern* contains no regex special characters.

        Safe literals can be used as plain ``in`` substring checks without
        risk of false positives from regex metacharacters accidentally
        matching unrelated text (e.g. ``google\\.com`` is not safe because
        the backslash is a special char, but ``googletagmanager.com/gtm.js``
        is safe).
        """
        return not any(ch in _REGEX_SPECIALS for ch in pattern)

    def _classify_domain(
        self,
        domain: str,
        fingerprints: list[Fingerprint],
    ) -> tuple[str | None, str | None]:
        """Reverse-lookup *domain* against fingerprints.

        Priority order
        --------------
        1. **Script pattern literal match** (primary):
           For each fingerprint, check every script pattern that is a safe
           literal (no regex special characters).  If that literal appears
           as a substring of *domain*, it is a candidate.  Among all
           candidates pick the one with the *longest* matching pattern
           (most specific); ties broken by fingerprint confidence.

           Example::

               fp "Google Maps" script "maps.googleapis.com"
               domain = "maps.googleapis.com"
               "maps.googleapis.com" in "maps.googleapis.com" -> True

               fp "FullStory" script "fullstory.com"
               domain = "rs.fullstory.com"
               "fullstory.com" in "rs.fullstory.com" -> True

        2. **Website suffix match** (fallback):
           Only reached when Step 1 produces no result.
           Strip scheme and ``www.`` from each fingerprint's ``website``
           field and check whether *domain* ends with that string.
           Among matches pick the longest suffix first, then highest
           confidence fingerprint.

        3. **Unclassified**:
           ``(None, None)`` — caller maps this to ``"Unclassified"``.
        """
        domain_lower = domain.lower()

        # ------------------------------------------------------------------
        # Step 1 — Script pattern literal match (primary)
        # ------------------------------------------------------------------
        # (pattern_length, confidence, name, category)
        script_candidates: list[tuple[int, float, str, str]] = []

        for fp in fingerprints:
            for pattern in fp.scripts:
                if not pattern:
                    continue
                pat_lower = pattern.lower()
                if self._is_safe_literal_pattern(pat_lower) and pat_lower in domain_lower:
                    script_candidates.append(
                        (len(pat_lower), fp.confidence, fp.name, fp.category)
                    )

        if script_candidates:
            # Longest pattern first (most specific); ties broken by confidence
            script_candidates.sort(key=lambda t: (-t[0], -t[1]))
            _, _, best_name, best_category = script_candidates[0]
            return best_name, best_category

        # ------------------------------------------------------------------
        # Step 2 — Website suffix match (fallback)
        # ------------------------------------------------------------------
        website_lookup: dict[str, list[dict[str, Any]]] = {}
        for fp in fingerprints:
            if not fp.website:
                continue
            try:
                parsed = urlparse(fp.website)
                netloc = parsed.netloc.lower()
                if not netloc and "//" not in fp.website:
                    parsed = urlparse("//" + fp.website)
                    netloc = parsed.netloc.lower()
                if netloc:
                    host = netloc.split(":")[0]
                    site_domain = host.removeprefix("www.")
                    if site_domain:
                        website_lookup.setdefault(site_domain, []).append({
                            "name": fp.name,
                            "category": fp.category,
                            "confidence": fp.confidence,
                        })
            except Exception:
                continue

        # (match_len, confidence, name, category)
        website_candidates: list[tuple[int, float, str, str]] = []

        for site_domain, fp_infos in website_lookup.items():
            if domain_lower == site_domain or domain_lower.endswith("." + site_domain):
                # Suffix match on a shared platform domain is disallowed
                # (e.g. www.google.com matching google.com suffix is blocked,
                # but maps.google.com matching maps.google.com exactly is allowed)
                if domain_lower != site_domain and site_domain in _SHARED_DOMAINS:
                    continue
                match_len = len(site_domain)
                for info in fp_infos:
                    if self._brand_matches(info["name"], domain):
                        website_candidates.append(
                            (match_len, info["confidence"], info["name"], info["category"])
                        )

        if website_candidates:
            # Longest suffix first, then highest confidence
            website_candidates.sort(key=lambda t: (-t[0], -t[1]))
            _, _, best_name, best_category = website_candidates[0]
            return best_name, best_category

        # ------------------------------------------------------------------
        # Step 3 — Unclassified
        # ------------------------------------------------------------------
        return None, None

    # ------------------------------------------------------------------
    # Part 2 — Internal subdomain discovery via crt.sh
    # ------------------------------------------------------------------

    async def _discover_internal_subdomains(self) -> list[dict[str, object]]:
        """Query subdomain sources in fallback chain, then probe each one live."""
        if not self._target_domain:
            return []

        subdomains = await self._fetch_crtsh_subdomains()
        if not subdomains:
            logger.debug("DomainMapper: no subdomains discovered for %s", self._target_domain)
            return []

        source_name = getattr(self, "_ct_source", "crt.sh")
        logger.debug(
            "DomainMapper: probing %d subdomains from %s for %s",
            len(subdomains),
            source_name,
            self._target_domain,
        )

        # Probe concurrently with a semaphore cap (Pattern 9)
        semaphore = asyncio.Semaphore(_PROBE_CONCURRENCY)
        all_fingerprints = self._store.get_all()

        async with httpx.AsyncClient(
            follow_redirects=False,   # capture 301/302 redirect_location manually
            verify=False,             # noqa: S501 — intentional, scanning unknown certs
            timeout=httpx.Timeout(_PROBE_TIMEOUT),
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/125.0.0.0 Safari/537.36"
                )
            },
        ) as client:
            tasks = [
                self._probe_subdomain(client, sub, semaphore, all_fingerprints, source_name)
                for sub in subdomains
            ]
            probe_results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out None (connection errors) and exceptions
        internal_subs: list[dict[str, object]] = []
        for r in probe_results:
            if isinstance(r, dict):
                internal_subs.append(r)
            elif isinstance(r, Exception):
                logger.debug("DomainMapper probe exception: %s", r)

        # Sort by subdomain name for deterministic output
        internal_subs.sort(key=lambda x: str(x.get("subdomain") or ""))
        return internal_subs

    async def _fetch_crtsh_subdomains(self) -> list[str]:
        """Race all three CT sources concurrently; use the first that returns results.

        All three sources are launched simultaneously.  As soon as one returns
        a non-empty list, the remaining tasks are cancelled.  If none return
        results, a warning is logged and an empty list is returned.

        Sets ``self._ct_source`` to the name of the winning source.
        """
        sources: list[tuple[str, asyncio.Task[list[str]]]] = [
            ("hackertarget", asyncio.ensure_future(self._fetch_hackertarget_subdomains())),
            ("crt.sh",       asyncio.ensure_future(self._fetch_crtsh_subdomains_inner())),
            ("certspotter",  asyncio.ensure_future(self._fetch_certspotter_subdomains())),
        ]
        pending: set[asyncio.Task[list[str]]] = {t for _, t in sources}
        # name look-up: task -> source_name
        task_name: dict[asyncio.Task[list[str]], str] = {t: n for n, t in sources}

        errors: list[str] = []
        result: list[str] = []

        while pending:
            done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                source = task_name[task]
                exc = task.exception()
                if exc is not None:
                    errors.append(f"{source} error: {exc}")
                    logger.debug("DomainMapper: %s failed: %s", source, exc)
                    continue
                subdomains = task.result()
                if subdomains:
                    # Got results — cancel remaining and return immediately
                    for t in pending:
                        t.cancel()
                    # Await cancellations silently
                    if pending:
                        await asyncio.gather(*pending, return_exceptions=True)
                    self._ct_source = source
                    logger.debug(
                        "DomainMapper: %s returned %d subdomains for %s",
                        source, len(subdomains), self._target_domain,
                    )
                    return subdomains
                else:
                    errors.append(f"{source} returned 0 subdomains")

        # All three finished with no results
        warning_msg = f"All subdomain sources failed/empty: {'; '.join(errors)}"
        logger.warning(warning_msg)
        self.errors.append("All subdomain sources unavailable, subdomain discovery skipped")
        return result

    async def _fetch_crtsh_subdomains_inner(self) -> list[str]:
        """Query crt.sh and return de-duped, filtered subdomains."""
        url = f"https://crt.sh/?q=%.{self._target_domain}&output=json"
        headers = {
            "User-Agent": "stacksniff/0.1.0 (Certificate Transparency lookup)"
        }
        entries = None
        backoff_delays = [0.0, 2.0, 4.0]
        last_exc = None

        for attempt, delay in enumerate(backoff_delays, start=1):
            if delay > 0:
                await asyncio.sleep(delay)
            try:
                async with httpx.AsyncClient(
                    timeout=httpx.Timeout(15.0),
                    follow_redirects=True,
                ) as client:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code != 200:
                        raise httpx.HTTPStatusError(
                            f"HTTP {resp.status_code}",
                            request=resp.request,
                            response=resp
                        )
                    entries = resp.json()
                    break
            except Exception as exc:
                logger.debug("crt.sh query failed on attempt %d: %s", attempt, exc)
                last_exc = exc
        else:
            if last_exc:
                raise last_exc
            raise RuntimeError("crt.sh retries exhausted without response")

        if entries is None:
            return []

        suffix = f".{self._target_domain}"
        seen: set[str] = set()
        result: list[str] = []

        for entry in entries:
            name_value = entry.get("name_value", "")
            for name in name_value.split("\n"):
                name = name.strip().lower()
                if not name:
                    continue
                if name.startswith("*."):
                    continue  # skip wildcards
                if not name.endswith(suffix) and name != self._target_domain:
                    continue
                if name in seen:
                    continue
                seen.add(name)
                result.append(name)

        return result

    async def _fetch_hackertarget_subdomains(self) -> list[str]:
        """Query HackerTarget and return de-duped, filtered subdomains."""
        url = f"https://api.hackertarget.com/hostsearch/?q={self._target_domain}"
        headers = {
            "User-Agent": "stacksniff/0.1.0 (Certificate Transparency lookup)"
        }
        text = ""
        last_exc = None

        # 1 retry = 2 attempts total
        for attempt in range(1, 3):
            try:
                async with httpx.AsyncClient(
                    timeout=httpx.Timeout(10.0),
                    follow_redirects=True,
                ) as client:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code != 200:
                        raise httpx.HTTPStatusError(
                            f"HTTP {resp.status_code}",
                            request=resp.request,
                            response=resp
                        )
                    text = resp.text
                    break
            except Exception as exc:
                logger.debug("HackerTarget query failed on attempt %d: %s", attempt, exc)
                last_exc = exc
        else:
            if last_exc:
                raise last_exc
            raise RuntimeError("HackerTarget retries exhausted without response")

        if "API count exceeded" in text or "error check your search parameter" in text:
            raise RuntimeError(f"HackerTarget returned error: {text.strip()}")

        suffix = f".{self._target_domain}"
        seen: set[str] = set()
        result: list[str] = []

        for line in text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            if not parts:
                continue
            sub = parts[0].strip().lower()
            if not sub or sub.startswith("*."):
                continue
            if not sub.endswith(suffix) and sub != self._target_domain:
                continue
            if sub in seen:
                continue
            seen.add(sub)
            result.append(sub)

        return result

    async def _fetch_certspotter_subdomains(self) -> list[str]:
        """Query CertSpotter and return de-duped, filtered subdomains."""
        url = f"https://api.certspotter.com/v1/issuances?domain={self._target_domain}&include_subdomains=true&expand=dns_names"
        headers = {
            "User-Agent": "stacksniff/0.1.0 (Certificate Transparency lookup)"
        }
        data = None
        last_exc = None

        # 1 retry = 2 attempts total
        for attempt in range(1, 3):
            try:
                async with httpx.AsyncClient(
                    timeout=httpx.Timeout(10.0),
                    follow_redirects=True,
                ) as client:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code != 200:
                        raise httpx.HTTPStatusError(
                            f"HTTP {resp.status_code}",
                            request=resp.request,
                            response=resp
                        )
                    data = resp.json()
                    break
            except Exception as exc:
                logger.debug("CertSpotter query failed on attempt %d: %s", attempt, exc)
                last_exc = exc
        else:
            if last_exc:
                raise last_exc
            raise RuntimeError("CertSpotter retries exhausted without response")

        if not isinstance(data, list):
            raise ValueError("CertSpotter response is not a JSON array")

        suffix = f".{self._target_domain}"
        seen: set[str] = set()
        result: list[str] = []

        for item in data:
            dns_names = item.get("dns_names")
            if not dns_names or not isinstance(dns_names, list):
                continue
            for name in dns_names:
                name = name.strip().lower()
                if not name or name.startswith("*."):
                    continue
                if not name.endswith(suffix) and name != self._target_domain:
                    continue
                if name in seen:
                    continue
                seen.add(name)
                result.append(name)

        return result

    async def _probe_subdomain(
        self,
        client: httpx.AsyncClient,
        subdomain: str,
        semaphore: asyncio.Semaphore,
        fingerprints: list[Fingerprint],
        ct_source: str,
    ) -> dict[str, Any] | None:
        """HEAD-probe a single subdomain and classify its tech stack.

        Returns a result dict on success (200/301/302/401/403), or
        ``None`` for connection errors / DNS failures.
        """
        full_url = f"https://{subdomain}"
        async with semaphore:
            t0 = time.monotonic()
            try:
                resp = await client.head(full_url)
            except (httpx.ConnectError, OSError):
                # DNS failures and refused connections surface as ConnectError or OSError
                try:
                    full_url = f"http://{subdomain}"
                    resp = await client.head(full_url)
                except Exception:
                    return None
            except httpx.TimeoutException:
                return None
            except Exception as exc:  # noqa: BLE001
                logger.debug("DomainMapper: probe %s error: %s", subdomain, exc)
                return None

            response_time_ms = (time.monotonic() - t0) * 1000

        status = resp.status_code
        # Only keep responses that indicate a live host
        if status not in {200, 201, 204, 301, 302, 307, 308, 401, 403}:
            return None

        # Normalise headers for easy lookup
        lower_headers = {k.lower(): v for k, v in resp.headers.items()}
        content_type = lower_headers.get("content-type")
        redirect_statuses = {301, 302, 307, 308}
        redirect_location = (
            lower_headers.get("location") if status in redirect_statuses else None
        )

        # Tech detection from response headers
        detected_tech: str | None = None
        detected_category: str | None = None
        if lower_headers:
            detected_tech, detected_category = self._classify_by_headers(
                lower_headers, fingerprints
            )

        # Fix 3: If a redirect_location points to a completely different base domain
        # (not the same apex domain as the subdomain), the tech detection is
        # unreliable — clear it to avoid false positives like
        # "shop.github.com → thegithubshop.com" being labelled as GitHub tech.
        if redirect_location and detected_tech is not None:
            try:
                redirect_netloc = urlparse(redirect_location).netloc.lower().split(":")[0]
                # Strip www. for comparison
                redirect_base = redirect_netloc.removeprefix("www.")
                # Extract apex domain (last two parts) from both
                def _apex(host: str) -> str:
                    parts = host.split(".")
                    return ".".join(parts[-2:]) if len(parts) >= 2 else host

                if redirect_base and _apex(redirect_base) != _apex(self._target_domain):
                    logger.debug(
                        "DomainMapper: clearing tech for %s — redirect to external domain %s",
                        subdomain,
                        redirect_location,
                    )
                    detected_tech = None
                    detected_category = None
            except Exception:
                pass

        return {
            "subdomain": subdomain,
            "full_url": full_url,
            "status_code": status,
            "content_type": content_type,
            "redirect_location": redirect_location,
            "response_time_ms": round(response_time_ms, 1),
            "detected_tech": detected_tech,
            "detected_category": detected_category,
            "ct_source": ct_source,
        }

    def _classify_by_headers(
        self,
        lower_headers: dict[str, str],
        fingerprints: list[Fingerprint],
    ) -> tuple[str | None, str | None]:
        """Match response headers against fingerprint header patterns."""
        best_name: str | None = None
        best_category: str | None = None
        best_confidence: float = -1.0

        for fp in fingerprints:
            if fp.confidence <= best_confidence:
                continue
            for header_key, pattern_str in fp.headers.items():
                val = lower_headers.get(header_key.lower())
                if val is not None and self._is_specific_match(pattern_str, val):
                    if fp.confidence > best_confidence:
                        best_name = fp.name
                        best_category = fp.category
                        best_confidence = fp.confidence
                    break

        # Apply minimum confidence threshold (Fix 3)
        if best_confidence < 0.75:
            best_name = None
            best_category = None

        # Apply formatting checks (Fix 3)
        if best_name and (
            len(best_name) > 30 or not re.match(r"^[A-Za-z0-9 .-]+$", best_name)
        ):
            best_name = None
            best_category = None

        return best_name, best_category
