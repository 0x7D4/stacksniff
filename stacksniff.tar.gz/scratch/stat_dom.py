import json
import httpx
import asyncio

async def main():
    source_url = "https://raw.githubusercontent.com/enthec/webappanalyzer/main/src/technologies/"
    async with httpx.AsyncClient() as client:
        # Let's fetch all JSON files and inspect all technologies that use 'dom'
        chars = [chr(c) for c in range(ord("a"), ord("z") + 1)] + ["_"]
        dom_types = {}
        for c in chars:
            url = f"{source_url}{c}.json"
            try:
                r = await client.get(url)
                data = r.json()
                for name, tech in data.items():
                    if "dom" in tech:
                        dom = tech["dom"]
                        # Categorize dom
                        if isinstance(dom, str):
                            dom_types["string"] = dom_types.get("string", 0) + 1
                        elif isinstance(dom, list):
                            dom_types["list"] = dom_types.get("list", 0) + 1
                        elif isinstance(dom, dict):
                            dom_types["dict"] = dom_types.get("dict", 0) + 1
                            # Check keys inside dict
                            for sel, rules in dom.items():
                                if isinstance(rules, dict):
                                    for rule_key in rules.keys():
                                        dom_types[f"dict_rule_{rule_key}"] = dom_types.get(f"dict_rule_{rule_key}", 0) + 1
                                else:
                                    dom_types["dict_rule_plain"] = dom_types.get("dict_rule_plain", 0) + 1
            except Exception as e:
                print(f"Error {c}: {e}")
        print("DOM structure stats:")
        print(json.dumps(dom_types, indent=2))

asyncio.run(main())
