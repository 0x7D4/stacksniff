import http.server
import socketserver
import threading
import time
import sys
from typer.testing import CliRunner
from stacksniff.cli import app

# Reconfigure stdout to use utf-8 to print Rich unicode characters safely on Windows
sys.stdout.reconfigure(encoding='utf-8')

class MockHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        if self.path == "/openapi.json":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b"""{
                "openapi": "3.0.0",
                "info": {"title": "Mock API", "version": "1.0.0"},
                "paths": {
                    "/api/v1/users": {"get": {}, "post": {}},
                    "/api/v1/health": {"get": {}}
                }
            }""")
        else:
            self.send_response(404)
            self.end_headers()

def run_server():
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(("127.0.0.1", 8888), MockHandler) as httpd:
            httpd.serve_forever()
    except Exception as e:
        print(f"Server error: {e}", file=sys.stderr)

def main():
    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()
    time.sleep(1.5)

    runner = CliRunner()
    print("Executing stacksniff CLI scan...")
    result = runner.invoke(app, ["scan", "http://127.0.0.1:8888"])
    print(result.output)

if __name__ == "__main__":
    main()
