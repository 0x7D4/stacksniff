import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            ignore_https_errors=True,
        )
        page = await context.new_page()
        
        requests = []
        def on_request(request):
            requests.append((request.url, request.resource_type))
            
        page.on("request", on_request)
        
        print("Navigating...")
        await page.goto("https://aiori.in", wait_until="networkidle")
        print(f"Final URL: {page.url}")
        
        await asyncio.sleep(2)
        
        print("\nCaptured Requests:")
        for url, rtype in requests:
            print(f"[{rtype}] {url}")
            
        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())
