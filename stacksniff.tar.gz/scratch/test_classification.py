import yaml
import re
from pathlib import Path
from urllib.parse import urlparse

class Fingerprint:
    def __init__(self, name, category, website, scripts, confidence=0.5):
        self.name = name
        self.category = category
        self.website = website
        self.scripts = scripts
        self.confidence = confidence

def load_fingerprints(path: Path) -> list[Fingerprint]:
    with path.open("r", encoding="utf-8") as f:
        raw_data = yaml.safe_load(f) or {}
    
    categories = raw_data.get("categories", {})
    technologies = []
    
    raw_techs = raw_data.get("technologies", {})
    for name, data in raw_techs.items():
        if not isinstance(data, dict):
            continue
        cat_slug = data.get("category", "other")
        cat_info = categories.get(cat_slug)
        category_name = cat_info.get("name", cat_slug) if isinstance(cat_info, dict) else cat_slug
        
        technologies.append(
            Fingerprint(
                name=data.get("name", name),
                category=category_name,
                website=data.get("website"),
                scripts=data.get("scripts", []),
                confidence=float(data.get("confidence", 0.5)),
            )
        )
    return technologies

def _extract_domain_from_pattern(pattern: str) -> str | None:
    truncated = ""
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == '\\':
            if i + 1 < len(pattern):
                next_c = pattern[i+1]
                if next_c in (".", "-", "/"):
                    truncated += next_c
                    i += 2
                    continue
                elif next_c == "/":
                    truncated += "/"
                    i += 2
                    continue
            i += 1
            continue
        elif c in ("/", "(", "[", "*", "+", "?", "{", "|", "$", "^"):
            break
        else:
            truncated += c
            i += 1

    for part in re.split(r"[^a-zA-Z0-9.-]", truncated):
        part = part.strip(".")
        if "." in part and not part.startswith(".") and not part.endswith("."):
            labels = part.split(".")
            if len(labels) >= 2 and all(re.match(r"^[a-zA-Z0-9-]+$", l) for l in labels):
                return part.lower()
    return None

def _brand_matches(tech_name: str, domain: str) -> bool:
    tech_lower = tech_name.lower()
    domain_lower = domain.lower()
    
    # Extract words from the domain
    domain_labels = re.split(r"[^a-z0-9]", domain_lower)
    if len(domain_labels) > 1:
        domain_labels = domain_labels[:-1]  # Exclude TLD
    
    # Generic terms that shouldn't be used as brand matches on their own
    generic_stopwords = {
        "analytics", "pages", "platform", "cloud", "api", "apis", "cdn", "hosting",
        "services", "web", "hosted", "libraries", "font", "fonts", "ad", "ads",
        "adsense", "tag", "manager", "publisher", "exchange", "floodlight", "campaign",
        "management", "bot", "protector", "waf", "captcha", "security", "helper",
        "widget", "widgets", "connected", "static", "webchat", "members", "engine",
        "net", "com", "org", "co"
    }

    # Extract words from the technology name
    tech_words = [w for w in re.split(r"[^a-z0-9]", tech_lower) if w]
    if not tech_words:
        return False
        
    # The primary brand word is usually the first word (or first two if first is generic like 'google')
    brand_word = tech_words[0]
    if brand_word in ("google", "amazon", "microsoft", "adobe") and len(tech_words) > 1:
        brand_words = [brand_word, tech_words[1], brand_word + tech_words[1]]
    else:
        brand_words = [brand_word]

    # For each candidate brand word, check if it matches any label in the domain
    for bw in brand_words:
        if bw in generic_stopwords:
            continue
        for label in domain_labels:
            if bw == label:
                return True
            # Prefix match: label starts with the brand word (e.g. "githubusercontent" starts with "github")
            # Only allow if brand word is at least 5 characters to avoid short false positives (e.g. "fast" -> "fastly")
            if len(bw) >= 5 and label.startswith(bw):
                return True
                
    return False

def classify_domain(domain: str, fingerprints: list[Fingerprint]) -> tuple[str | None, str | None]:
    domain_lower = domain.lower()
    
    best_name = None
    best_category = None
    best_confidence = -1.0
    
    # 1. Build and check website suffix map
    website_lookup = {}
    for fp in fingerprints:
        if fp.website:
            try:
                parsed = urlparse(fp.website)
                netloc = parsed.netloc.lower()
                if not netloc and "//" not in fp.website:
                    parsed = urlparse("//" + fp.website)
                    netloc = parsed.netloc.lower()
                if netloc:
                    host = netloc.split(":")[0]
                    site_domain = host.removeprefix("www.")
                    if site_domain:
                        existing = website_lookup.get(site_domain)
                        if existing is None or fp.confidence > existing.confidence:
                            website_lookup[site_domain] = fp
            except Exception:
                continue

    for site_domain, fp in website_lookup.items():
        if domain_lower == site_domain or domain_lower.endswith("." + site_domain):
            if fp.confidence > best_confidence:
                best_name = fp.name
                best_category = fp.category
                best_confidence = fp.confidence

    if best_name is not None:
        return best_name, best_category

    # 2. Build and check script patterns domain map
    script_lookup = {}
    for fp in fingerprints:
        for pattern in fp.scripts:
            extracted = _extract_domain_from_pattern(pattern)
            if extracted:
                script_lookup.setdefault(extracted, []).append(fp)

    # Find matches where target domain matches/ends-with extracted script domain
    matches = []
    for script_domain, fps in script_lookup.items():
        if domain_lower == script_domain or domain_lower.endswith("." + script_domain):
            for fp in fps:
                matches.append((fp, script_domain))

    if matches:
        # If there are matches, let's filter/score them:
        # Prefer matches where the technology brand matches the domain name.
        brand_matches = [m for m in matches if _brand_matches(m[0].name, domain_lower)]
        if brand_matches:
            brand_matches.sort(key=lambda m: (-len(m[1]), -m[0].confidence))
            best = brand_matches[0][0]
            return best.name, best.category
            
        # If no brand match, check if there's a unique match
        if len(matches) == 1:
            return matches[0][0].name, matches[0][0].category

    # 3. Fallback: Heuristic brand-matching against all fingerprint names
    brand_matches = []
    for fp in fingerprints:
        if _brand_matches(fp.name, domain_lower):
            brand_matches.append(fp)
            
    if brand_matches:
        # Prefer cdn/paas/hosting/analytics categories for heuristic domain brand matches
        brand_matches.sort(key=lambda fp: (
            0 if fp.category.lower() in ("cdn", "paas", "hosting", "analytics", "advertising") else 1,
            -fp.confidence
        ))
        return brand_matches[0].name, brand_matches[0].category

    return None, None

# Test target domains
test_domains = [
    "googleapis.com",
    "ajax.googleapis.com",
    "gstatic.com",
    "googletagmanager.com",
    "google-analytics.com",
    "googlesyndication.com",
    "googleadservices.com",
    "2mdn.net",
    "doubleclick.net",
    "githubassets.com",
    "githubusercontent.com",
    "jsdelivr.net",
    "cdn.jsdelivr.net",
    "fastly.net",
    "fastlylb.net",
    "akamaiedge.net",
    "akamaitechnologies.com",
    "akadns.net",
    "amazonaws.com",
    "awsstatic.com",
    "cloudfront.net",
    "aumentstaticfiles.s3.amazonaws.com"
]

print("Loading tech.yaml...")
fingerprints = load_fingerprints(Path("fingerprints/tech.yaml"))
print(f"Loaded {len(fingerprints)} fingerprints.")

print("\n--- CLASSIFICATION RESULTS ---")
for d in test_domains:
    name, category = classify_domain(d, fingerprints)
    print(f"{d:35} -> name: {str(name):25} category: {str(category)}")
