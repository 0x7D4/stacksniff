import asyncio
import http.server
import socketserver
import threading
import time
import sys
import httpx
from stacksniff.scanner import Scanner

# Mock server handler that serves an OpenAPI spec
class MockHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        # Suppress logging to keep output clean
        pass

    def do_GET(self):
        if self.path == "/openapi.json":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b"""{
                "openapi": "3.0.0",
                "info": {"title": "Mock API", "version": "1.0.0"},
                "paths": {
                    "/api/v1/users": {"get": {}, "post": {}},
                    "/api/v1/health": {"get": {}}
                }
            }""")
        else:
            self.send_response(404)
            self.end_headers()

def run_server():
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(("127.0.0.1", 8888), MockHandler) as httpd:
            httpd.serve_forever()
    except Exception as e:
        print(f"Server error: {e}", file=sys.stderr)

async def main():
    # Start server in background thread
    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()
    time.sleep(1.5) # wait for server to start

    # Test direct connection
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get("http://127.0.0.1:8888/openapi.json")
            print(f"Direct connection test status: {resp.status_code}")
    except Exception as e:
        print(f"Direct connection failed: {e}")

    print("Running stacksniff scanner against local mock OpenAPI server...\n")
    scanner = Scanner()
    # Scan with browser=True (default) to utilize the full Playwright + NetworkCollector engine
    result = await scanner.scan("http://127.0.0.1:8888", browser=True)

    print("Scan Result:")
    print(f"  URL: {result.url}")
    print(f"  OpenAPI Spec Found: {result.openapi_spec_found}")
    print("\nAPI Endpoints Detected:")
    for ep in result.api_endpoints:
        print(f"  - {ep.method:6} {ep.url:20} (Confidence: {ep.confidence}, Matched by: {ep.pattern_matched})")

if __name__ == "__main__":
    asyncio.run(main())
