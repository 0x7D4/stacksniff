from stacksniff.collectors.framework_prober import FrameworkProber, _default_seclists_dir
from stacksniff.models import TechMatch
import yaml
from pathlib import Path

# Mock detected technologies from iifon.org scan
detected_tech_names = [
    "WordPress", "Conditional Fields for Contact Form 7", "Elementor", "Font Awesome", 
    "Slider Revolution", "cdnjs", "imagesLoaded", "jQuery Migrate", "Magnific Popup", 
    "Recent Posts Widget With Thumbnails", "Smash Balloon Instagram Feed", "Swiper", 
    "Apache HTTP Server", "Google Font API", "Instagram Feed for WordPress", "jQuery", 
    "Open Graph", "PHP", "Popup Maker", "reCAPTCHA", "RSS", "WordPress Block Editor", 
    "Cloudflare", "Contact Form 7", "MySQL", "gsap"
]

techs = [
    TechMatch(name=name, category="other", version=None, confidence=0.8, evidence=[])
    for name in detected_tech_names
]

prober = FrameworkProber(techs, "https://iifon.org")
seclists_dir = prober._seclists_dir or _default_seclists_dir()
manifest = yaml.safe_load((seclists_dir / "manifest.yaml").open("r", encoding="utf-8"))

detected_names = prober._detected_tech_names_lower()
print("Detected Names Lower:", detected_names)

included_files = prober._build_probe_list(manifest["files"], seclists_dir)

print("\n--- Included Files via Technology Matches ---")
for fn in sorted(included_files.keys()):
    meta = manifest["files"][fn]
    print(f"File: {fn:35} | tech_match: {meta.get('tech_match')}")

