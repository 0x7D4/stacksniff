import json
import httpx
import asyncio

async def main():
    source_url = "https://raw.githubusercontent.com/enthec/webappanalyzer/main/src/technologies/"
    async with httpx.AsyncClient() as client:
        # Google Font API is in g.json
        # RSS is in r.json
        # LottieFiles is in l.json
        # PWA is in p.json
        # Open Graph is in o.json
        chars = ["g", "r", "l", "p", "o"]
        for c in chars:
            url = f"{source_url}{c}.json"
            r = await client.get(url)
            data = r.json()
            for name in ["Google Font API", "RSS", "LottieFiles", "PWA", "Open Graph"]:
                if name in data:
                    print(f"--- {name} ---")
                    print(json.dumps(data[name], indent=2))

asyncio.run(main())
