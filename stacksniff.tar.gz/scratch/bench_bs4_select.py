import time
from bs4 import BeautifulSoup
import httpx
import asyncio

async def main():
    # Fetch youtube.com html
    async with httpx.AsyncClient() as client:
        r = await client.get("https://youtube.com")
        html = r.text
    
    t0 = time.monotonic()
    soup = BeautifulSoup(html, "html.parser")
    print(f"BS4 Parse took {time.monotonic() - t0:.3f}s")

    # Generate 1500 mock selectors
    selectors = [
        "link[rel='manifest']",
        "meta[property*='og:']",
        "lottie-player",
        "link[href*='fonts.g']",
        "style[data-href*='fonts.g']",
        "div[data-testid='lottie-player']",
    ] + [f"div.class-{i}" for i in range(1500)]

    t0 = time.monotonic()
    match_count = 0
    for sel in selectors:
        try:
            res = soup.select(sel)
            if res:
                match_count += 1
        except Exception:
            pass
    print(f"Selecting 1500 queries took {time.monotonic() - t0:.3f}s (matched {match_count})")

asyncio.run(main())
