import re
from stacksniff.fingerprints import FingerprintStore

store = FingerprintStore.default()
technologies = list(store.technologies.keys())

def matches_technology(normalized_filename: str, tech_key: str) -> bool:
    # Split both into words
    file_words = set(re.findall(r'\b\w+\b', normalized_filename.lower()))
    tech_words = set(re.findall(r'\b\w+\b', tech_key.lower()))
    
    # Filter out generic words
    generic_words = {
        "api", "endpoints", "seen", "in", "wild", "the", "fuzz", "common", "objects",
        "actions", "directories", "files", "lowercase", "medium", "small", "large",
        "big", "raft", "list", "words", "quickhits", "versioning", "metafiles",
        "backups", "default", "web", "root", "linux", "windows", "unix", "dotfiles",
        "logins", "passwords", "functions", "scopes", "auth", "oauth", "oidc",
        "top", "million", "bug", "bounty", "program", "inventory", "trickest",
        "subdomains", "dns", "top1million"
    }
    
    clean_file_words = file_words - generic_words
    clean_tech_words = tech_words - generic_words
    
    if not clean_file_words or not clean_tech_words:
        return False
        
    # Check if the clean file words are a subset of clean tech words, or vice versa
    if clean_file_words.issubset(clean_tech_words) or clean_tech_words.issubset(clean_file_words):
        return True
        
    return False

test_cases = [
    ("coldfusion", "adobe coldfusion", True),
    ("big", "bigcommerce", False),
    ("big", "f5 bigip", False),
    ("common", "common ground", False),
    ("django", "django", True),
    ("drupal", "drupal", True),
    ("wordpress plugins", "wordpress", True),
    ("wordpress themes", "wordpress", True),
    ("joomla plugins", "joomla", True),
    ("hashicorp consul api", "hashicorp consul", True),
    ("hashicorp vault", "hashicorp vault", True),
    ("salesforce aura objects", "salesforce", True),
    ("wso2 enterprise integrator", "wso2", True),
]

print("--- Running Test Cases ---")
for filename, tech_key, expected in test_cases:
    res = matches_technology(filename, tech_key)
    print(f"File: {filename:25} | Tech: {tech_key:25} | Expected: {expected} | Got: {res} | {'PASS' if res == expected else 'FAIL'}")

print("\n--- Listing Matches in Store for Filenames ---")
filenames_to_check = [
    "big", "common", "coldfusion", "django", "drupal", "wordpress plugins", 
    "wordpress themes", "joomla plugins", "hashicorp consul api", "hashicorp vault", 
    "salesforce aura objects", "wso2 enterprise integrator", "quickhits", "versioning metafiles"
]

for fname in filenames_to_check:
    matches = [tech for tech in technologies if matches_technology(fname, tech)]
    print(f"File: {fname:30} -> Matches ({len(matches)}): {matches[:10]}")
