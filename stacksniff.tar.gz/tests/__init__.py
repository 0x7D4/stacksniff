"""Unit tests for stacksniff."""
